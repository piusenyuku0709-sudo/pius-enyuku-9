clc;
clear;
close all;

% MANUFACTURING OPTIMIZATION USING FMINCON

% Objective function (maximize profit)
% fmincon minimizes, therefore use negative profit

f = @(x) -(50*x(1) + 40*x(2) + 35*x(3));

% Number of decision variables
% x(1) = A, x(2) = B, x(3) = C

% Resource constraint matrix
A = [2 1 1;
     1 2 1;
     3 2 1];

% Available resources
b = [240; 200; 300];

% Equality constraints
Aeq = [];
beq = [];

% Lower and upper bounds
lb = [0; 0; 0];
ub = [60; 70; 80];

% Initial guess
x0 = [10; 10; 10];

% Optimization options
options = optimoptions('fmincon', ...
    'Display','iter', ...
    'Algorithm','sqp');

% Run fmincon optimizer
[x,fval,exitflag,output] = fmincon( ...
    f,x0,A,b,Aeq,beq,lb,ub,[],options);

% Calculate maximum profit
MaxProfit = -fval;

% Display optimal results
fprintf('\nFMINCON OPTIMIZATION RESULTS\n');

fprintf('Component A = %.2f units\n',x(1));
fprintf('Component B = %.2f units\n',x(2));
fprintf('Component C = %.2f units\n',x(3));

fprintf('Maximum Profit = %.2f currency units\n',MaxProfit);


% RESOURCE UTILIZATION

Machine = 2*x(1) + x(2) + x(3);
Labour = x(1) + 2*x(2) + x(3);
Material = 3*x(1) + 2*x(2) + x(3);

fprintf('\nRESOURCE UTILIZATION\n');

fprintf('Machine hours used = %.2f\n',Machine);
fprintf('Labour hours used = %.2f\n',Labour);
fprintf('Raw materials used = %.2f kg\n',Material);



% PLOT 1: Optimal production quantities

figure;

bar(x);

set(gca,'XTickLabel', ...
    {'Component A','Component B','Component C'});

xlabel('Components');
ylabel('Production Units');

title('Optimal Production Quantities');

grid on;


% PLOT 2: Resource utilization

figure;

Used = [Machine Labour Material];

Available = [240 200 300];

bar([Used; Available]');

set(gca,'XTickLabel', ...
    {'Machine Hours','Labour Hours','Raw Materials'});

xlabel('Resources');
ylabel('Resource Quantity');

title('Resource Utilization vs Available Resources');

legend('Resources Used','Resources Available');

grid on;


% PLOT 3: Profit contribution

figure;

Profit = [50*x(1), 40*x(2), 35*x(3)];

bar(Profit);

set(gca,'XTickLabel', ...
    {'Component A','Component B','Component C'});

xlabel('Components');
ylabel('Profit (Currency Units)');

title('Profit Contribution of Each Component');

grid on;
