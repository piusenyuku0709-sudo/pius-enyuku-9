clc;
clear;
close all;

% PROBLEM 2: MINIMUM FEED COST USING PATTERNSEARCH

% Objective function
objective = @(x) 0.45*x(1) + 0.85*x(2) + 0.35*x(3);

% Linear inequality constraints A*x <= b
A = [-0.09 -0.44 -0.16;
     -3300 -2450 -1800;
      0.02 0.07 0.10];

b = [-18; -280000; 8];

% Equality constraint
Aeq = [1 1 1];
beq = 100;

% Lower and upper bounds
lb = [0 0 0];
ub = [100 100 100];

% Initial guess (feasible)
x0 = [40 40 20];

% Optimization options
options = optimoptions('patternsearch', ...
    'Display','iter', ...
    'MaxIterations',500);

% Run Pattern Search
[x,fval,exitflag,output] = patternsearch( ...
    objective,x0,A,b,Aeq,beq,lb,ub,[],options);

% Calculate nutritional values
protein = 0.09*x(1)+0.44*x(2)+0.16*x(3);
energy = 3300*x(1)+2450*x(2)+1800*x(3);
fibre = 0.02*x(1)+0.07*x(2)+0.10*x(3);

% Display results
fprintf('\nOPTIMAL FEED FORMULATION\n');
fprintf('Maize = %.4f kg\n',x(1));
fprintf('Soybean meal = %.4f kg\n',x(2));
fprintf('Wheat bran = %.4f kg\n',x(3));
fprintf('Minimum Total Cost = %.4f\n',fval);

fprintf('\nNUTRITIONAL CHECK\n');
fprintf('Total weight = %.4f kg\n',sum(x));
fprintf('Protein = %.4f kg\n',protein);
fprintf('Energy = %.4f kcal\n',energy);
fprintf('Fibre = %.4f kg\n',fibre);

% Plot ingredient quantities
figure;
bar(x);
set(gca,'XTickLabel',{'Maize','Soybean Meal','Wheat Bran'});
ylabel('Quantity (kg)');
title('Optimal Feed Formulation Using Pattern Search');
grid on;