clc;
clear;
close all;

% PROBLEM 3: MINIMUM TANK COST USING PARTICLESWARM

% Decision variables:
% x(1) = Length
% x(2) = Width

% Height is calculated from the volume constraint
H = @(x) 3/(x(1)*x(2));

% Objective function
objective = @(x) 40*x(1)*x(2) + ...
    50*x(1)*H(x) + 50*x(2)*H(x);

% Lower and upper bounds
lb = [0.1 0.1];
ub = [5 5];

% Optimization options
options = optimoptions('particleswarm', ...
    'SwarmSize',100, ...
    'MaxIterations',500, ...
    'Display','iter');

% Run Particle Swarm Optimization
[x,fval,exitflag,output] = particleswarm( ...
    objective,2,lb,ub,options);

% Calculate optimal dimensions
L = x(1);
W = x(2);
height = 3/(L*W);

% Display results
fprintf('\nOPTIMAL TANK DIMENSIONS\n');
fprintf('Length = %.4f metres\n',L);
fprintf('Width = %.4f metres\n',W);
fprintf('Height = %.4f metres\n',height);
fprintf('Minimum Material Cost = %.4f\n',fval);

% Verify volume
volume = L*W*height;
fprintf('Tank Volume = %.4f cubic metres\n',volume);

% Plot tank dimensions
figure;

vertices = [0 0 0;
            L 0 0;
            L W 0;
            0 W 0;
            0 0 height;
            L 0 height;
            L W height;
            0 W height];

faces = [1 2 3 4;
         1 2 6 5;
         2 3 7 6;
         3 4 8 7;
         4 1 5 8];

patch('Vertices',vertices,'Faces',faces, ...
    'FaceColor','cyan','FaceAlpha',0.3, ...
    'EdgeColor','black','LineWidth',2);

xlabel('Length (m)');
ylabel('Width (m)');
zlabel('Height (m)');
title('Optimized Open-Top Storage Tank');
grid on;
axis equal;
view(3);