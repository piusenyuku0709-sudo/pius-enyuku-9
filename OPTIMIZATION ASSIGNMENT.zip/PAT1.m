clc;
clear;
close all;

% PROBLEM 1: MAXIMUM PROFIT USING PATTERNSEARCH

% Objective function
objective = @(x) -(50*x(1) + 40*x(2) + 35*x(3));

% Linear inequality constraints A*x <= b
A = [2 1 1;
     1 2 1;
     3 2 1];

b = [240; 200; 300];

% Lower and upper bounds
lb = [0 0 0];
ub = [60 70 80];

% Initial guess
x0 = [20 20 20];

% Optimization options
options = optimoptions('patternsearch', ...
    'Display','iter', ...
    'MaxIterations',500);

% Run Pattern Search
[x,fval,exitflag,output] = patternsearch( ...
    objective,x0,A,b,[],[],lb,ub,[],options);

% Calculate maximum profit
maximumProfit = -fval;

% Display results
fprintf('\nOPTIMAL PRODUCTION QUANTITIES\n');
fprintf('Component A = %.4f units\n',x(1));
fprintf('Component B = %.4f units\n',x(2));
fprintf('Component C = %.4f units\n',x(3));
fprintf('Maximum Profit = %.4f\n',maximumProfit);

% Resource utilization
fprintf('\nRESOURCE UTILIZATION\n');
fprintf('Machine hours = %.4f / 240\n',A(1,:)*x');
fprintf('Labour hours = %.4f / 200\n',A(2,:)*x');
fprintf('Raw material = %.4f / 300\n',A(3,:)*x');

% Plot results
figure;
bar(x);
set(gca,'XTickLabel',{'Component A','Component B','Component C'});
ylabel('Production Units');
title('Optimal Production Using Pattern Search');
grid on;