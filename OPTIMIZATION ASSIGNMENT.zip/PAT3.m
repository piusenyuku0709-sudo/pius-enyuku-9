clc;
clear;
close all;

% PROBLEM 3: MINIMUM TANK COST USING PATTERNSEARCH

% Decision variables:
% x(1) = Length
% x(2) = Width
% x(3) = Height

% Objective function
objective = @(x) 40*x(1)*x(2) + ...
    50*x(1)*x(3) + 50*x(2)*x(3);

% Nonlinear equality constraint
% Required volume = 3 cubic metres
nonlcon = @(x) deal([],x(1)*x(2)*x(3)-3);

% Lower and upper bounds
lb = [0.1 0.1 0.1];
ub = [5 5 5];

% Initial guess (satisfies volume constraint)
x0 = [1 1 3];

% Optimization options
options = optimoptions('patternsearch', ...
    'Display','iter', ...
    'MaxIterations',500);

% Run Pattern Search
[x,fval,exitflag,output] = patternsearch( ...
    objective,x0,[],[],[],[],lb,ub,nonlcon,options);

% Extract optimal dimensions
L = x(1);
W = x(2);
H = x(3);

% Display results
fprintf('\nOPTIMAL TANK DIMENSIONS\n');
fprintf('Length = %.4f metres\n',L);
fprintf('Width = %.4f metres\n',W);
fprintf('Height = %.4f metres\n',H);
fprintf('Minimum Material Cost = %.4f\n',fval);

% Verify volume
volume = L*W*H;
fprintf('Tank Volume = %.4f cubic metres\n',volume);

% Plot optimized tank
figure;

vertices = [0 0 0;
            L 0 0;
            L W 0;
            0 W 0;
            0 0 H;
            L 0 H;
            L W H;
            0 W H];

faces = [1 2 3 4;
         1 2 6 5;
         2 3 7 6;
         3 4 8 7;
         4 1 5 8];

patch('Vertices',vertices,'Faces',faces, ...
    'FaceColor','cyan','FaceAlpha',0.3, ...
    'EdgeColor','black','LineWidth',2);

xlabel('Length (m)');
ylabel('Width (m)');
zlabel('Height (m)');
title('Optimized Open-Top Storage Tank');
grid on;
axis equal;
view(3);