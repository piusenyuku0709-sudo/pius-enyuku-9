clc;
clear;
close all;

% PROBLEM 2: MINIMUM FEED COST USING PARTICLESWARM

% Objective function
objective = @(x) 0.45*x(1) + 0.85*x(2) + 0.35*x(3);

% Penalty for nutritional constraints
penalty = @(x) 1e6 * ( ...
    ((x(1)+x(2)+x(3)-100)/100)^2 + ...
    (max(0,(18-(0.09*x(1)+0.44*x(2)+0.16*x(3)))/18))^2 + ...
    (max(0,(280000-(3300*x(1)+2450*x(2)+1800*x(3)))/280000))^2 + ...
    (max(0,(0.02*x(1)+0.07*x(2)+0.10*x(3)-8)/8))^2 );

% Combined fitness function
fitness = @(x) objective(x) + penalty(x);

% Bounds
lb = [0 0 0];
ub = [100 100 100];

% Optimization options
options = optimoptions('particleswarm', ...
    'SwarmSize',150, ...
    'MaxIterations',500, ...
    'Display','iter');

% Run Particle Swarm Optimization
[x,fval,exitflag,output] = particleswarm( ...
    fitness,3,lb,ub,options);

% Display optimal quantities and cost
fprintf('\nOPTIMAL FEED FORMULATION\n');
fprintf('Maize = %.4f kg\n',x(1));
fprintf('Soybean meal = %.4f kg\n',x(2));
fprintf('Wheat bran = %.4f kg\n',x(3));
fprintf('Minimum Total Cost = %.4f\n',objective(x));

% Check nutritional requirements
protein = 0.09*x(1)+0.44*x(2)+0.16*x(3);
energy = 3300*x(1)+2450*x(2)+1800*x(3);
fibre = 0.02*x(1)+0.07*x(2)+0.10*x(3);

fprintf('\nNUTRITIONAL CHECK\n');
fprintf('Total weight = %.4f kg\n',sum(x));
fprintf('Protein = %.4f kg (Minimum 18 kg)\n',protein);
fprintf('Energy = %.4f kcal (Minimum 280000 kcal)\n',energy);
fprintf('Fibre = %.4f kg (Maximum 8 kg)\n',fibre);

% Plot ingredient quantities
figure;
bar(x);
set(gca,'XTickLabel',{'Maize','Soybean Meal','Wheat Bran'});
ylabel('Quantity (kg)');
title('Optimal Feed Formulation Using Particle Swarm');
grid on;