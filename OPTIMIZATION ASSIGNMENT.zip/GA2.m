%% Animal Feed Formulation – Genetic Algorithm Solution
% Minimize cost of 100 kg batch subject to protein, energy and fibre constraints

clear; clc; close all;

%% Decision variables
% x(1) = kg of maize
% x(2) = kg of soybean meal
% x(3) = kg of wheat bran

nvars = 3;

%% Objective function (total cost)
cost = @(x) 0.45*x(1) + 0.85*x(2) + 0.35*x(3);

%% Linear inequality constraints  A*x <= b
% Protein:  -0.09 x1 -0.44 x2 -0.16 x3  <= -18
% Energy:   -3300 x1 -2450 x2 -1800 x3  <= -280000
% Fibre:     0.02 x1 +0.07 x2 +0.10 x3  <=  8
A = [-0.09  -0.44  -0.16;
     -3300  -2450  -1800;
      0.02   0.07   0.10];
b = [-18; -280000; 8];

%% Linear equality constraint  Aeq*x = beq  (total mass = 100 kg)
Aeq = [1 1 1];
beq = 100;

%% Bounds
lb = [0 0 0];          % non-negative
ub = [100 100 100];    % cannot exceed total batch size

%% Genetic Algorithm options
opts = optimoptions('ga', ...
    'PopulationSize', 200, ...
    'MaxGenerations', 300, ...
    'EliteCount', 10, ...
    'CrossoverFraction', 0.8, ...
    'MutationFcn', @mutationadaptfeasible, ...
    'Display', 'iter', ...
    'PlotFcn', {@gaplotbestf, @gaplotstopping}, ...
    'UseParallel', false);

%% Run GA
rng default;                       % for reproducibility
[x_opt, fval, exitflag, output] = ga(cost, nvars, A, b, Aeq, beq, lb, ub, [], opts);

%% Display results
fprintf('\n========== OPTIMAL SOLUTION ==========\n');
fprintf('Maize          : %8.3f kg\n', x_opt(1));
fprintf('Soybean meal   : %8.3f kg\n', x_opt(2));
fprintf('Wheat bran     : %8.3f kg\n', x_opt(3));
fprintf('Total mass     : %8.3f kg\n', sum(x_opt));
fprintf('Minimum cost   : %8.3f currency units\n', fval);
fprintf('Generations    : %d\n', output.generations);
fprintf('Exit flag      : %d\n', exitflag);

%% Verify constraints
protein = 0.09*x_opt(1) + 0.44*x_opt(2) + 0.16*x_opt(3);
energy  = 3300*x_opt(1) + 2450*x_opt(2) + 1800*x_opt(3);
fibre   = 0.02*x_opt(1) + 0.07*x_opt(2) + 0.10*x_opt(3);

fprintf('\n--- Constraint check ---\n');
fprintf('Protein : %7.2f kg  (required ≥ 18)\n', protein);
fprintf('Energy  : %7.0f kcal (required ≥ 280000)\n', energy);
fprintf('Fibre   : %7.2f kg  (required ≤ 8)\n', fibre);

%% Extra visualisation – composition pie chart
figure('Name','Optimal Feed Composition','Color','w');
labels = {sprintf('Maize\n%.1f kg',x_opt(1)), ...
          sprintf('Soybean meal\n%.1f kg',x_opt(2)), ...
          sprintf('Wheat bran\n%.1f kg',x_opt(3))};
pie(x_opt, labels);
title(sprintf('Minimum-cost 100 kg batch\nTotal cost = %.2f', fval), ...
      'FontSize',12,'FontWeight','bold');
colormap([0.85 0.65 0.2; 0.2 0.6 0.3; 0.7 0.5 0.3]);