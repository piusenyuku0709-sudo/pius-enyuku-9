clc;
clear;
close all;

% PROBLEM 1: MAXIMUM PROFIT USING PARTICLESWARM

% Objective function (negative because PSO minimizes)
objective = @(x) - (50*x(1) + 40*x(2) + 35*x(3));

% Penalty function for constraints
penalty = @(x) 1e6 * ( ...
    max(0,(2*x(1)+x(2)+x(3)-240)/240)^2 + ...
    max(0,(x(1)+2*x(2)+x(3)-200)/200)^2 + ...
    max(0,(3*x(1)+2*x(2)+x(3)-300)/300)^2 );

% Combined objective function
fitness = @(x) objective(x) + penalty(x);

% Lower and upper bounds
lb = [0 0 0];
ub = [60 70 80];

% Optimization options
options = optimoptions('particleswarm', ...
    'SwarmSize',100, ...
    'MaxIterations',300, ...
    'Display','iter');

% Run Particle Swarm Optimization
[x,fval,exitflag,output] = particleswarm( ...
    fitness,3,lb,ub,options);

% Calculate maximum profit
maximumProfit = -objective(x);

% Display results
fprintf('\nOPTIMAL PRODUCTION QUANTITIES\n');
fprintf('Component A = %.4f units\n',x(1));
fprintf('Component B = %.4f units\n',x(2));
fprintf('Component C = %.4f units\n',x(3));
fprintf('Maximum Profit = %.4f\n',maximumProfit);

% Check resource usage
fprintf('\nRESOURCE UTILIZATION\n');
fprintf('Machine hours = %.4f / 240\n', ...
    2*x(1)+x(2)+x(3));
fprintf('Labour hours = %.4f / 200\n', ...
    x(1)+2*x(2)+x(3));
fprintf('Raw material = %.4f / 300\n', ...
    3*x(1)+2*x(2)+x(3));

% Plot optimal production quantities
figure;
bar(x);
set(gca,'XTickLabel',{'Component A','Component B','Component C'});
ylabel('Production Units');
title('Optimal Production Using Particle Swarm');
grid on;