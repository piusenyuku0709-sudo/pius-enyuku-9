clc;
clear;
close all;

% GENETIC ALGORITHM OPTIMIZATION

% Objective function (Maximize profit)
% GA minimizes, so use negative profit

fitness = @(x) -(50*x(1) + 40*x(2) + 35*x(3));

% Number of decision variables
nvars = 3;

% Resource constraint matrix
A = [2 1 1;
     1 2 1;
     3 2 1];

% Available resources
b = [240; 200; 300];

% Equality constraints
Aeq = [];
beq = [];

% Lower and upper bounds
lb = [0 0 0];
ub = [60 70 80];

% Nonlinear constraints
nonlcon = [];

% GA optimization options
options = optimoptions('ga', ...
    'Display','iter', ...
    'PopulationSize',100, ...
    'MaxGenerations',200, ...
    'PlotFcn',@gaplotbestf);

% Run Genetic Algorithm
[x,fval,exitflag,output] = ga( ...
    fitness,nvars,A,b,Aeq,beq,lb,ub,nonlcon,options);

% Calculate maximum profit
MaxProfit = -fval;

% Display optimal results
fprintf('\nGENETIC ALGORITHM RESULTS\n');

fprintf('Component A = %.2f units\n',x(1));
fprintf('Component B = %.2f units\n',x(2));
fprintf('Component C = %.2f units\n',x(3));

fprintf('Maximum Profit = %.2f currency units\n',MaxProfit);


% RESOURCE UTILIZATION
Machine = 2*x(1) + x(2) + x(3);
Labour = x(1) + 2*x(2) + x(3);
Material = 3*x(1) + 2*x(2) + x(3);

fprintf('\nRESOURCE UTILIZATION\n');

fprintf('Machine hours used = %.2f\n',Machine);
fprintf('Labour hours used = %.2f\n',Labour);
fprintf('Raw materials used = %.2f kg\n',Material);


% =================================
% PLOTTING SECTION
% =================================

% PLOT 1: Optimal production quantities

figure;

bar(x);

set(gca,'XTickLabel',{'Component A','Component B','Component C'});

xlabel('Components');
ylabel('Production Units');
title('Optimal Production Quantities');

grid on;


% PLOT 2: Resource utilization

figure;

Used = [Machine Labour Material];
Available = [240 200 300];

bar([Used;Available]');

set(gca,'XTickLabel',{'Machine Hours','Labour Hours','Raw Materials'});

xlabel('Resources');
ylabel('Resource Quantity');

title('Resource Utilization vs Available Resources');

legend('Resources Used','Resources Available');

grid on;