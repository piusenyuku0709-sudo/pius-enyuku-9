clc;
clear;
close all;

% Number of variables
nvars = 3;

% Objective function
objective = @(x) 40*x(1)*x(2) + ...
                  50*x(1)*x(3) + ...
                  50*x(2)*x(3);

% Lower bounds
lb = [0.01 0.01 0.01];

% Upper bounds
ub = [5 5 5];

% Nonlinear volume constraint
nonlcon = @(x) deal([], x(1)*x(2)*x(3)-3);

% GA optimization options
options = optimoptions('ga', ...
    'Display','iter', ...
    'PopulationSize',100, ...
    'MaxGenerations',200, ...
    'PlotFcn',@gaplotbestf);

% Run Genetic Algorithm
[x_opt,fval] = ga(objective,nvars,...
    [],[],[],[],lb,ub,nonlcon,options);

% Extract dimensions
L = x_opt(1);
W = x_opt(2);
H = x_opt(3);

% Display results
fprintf('GA OPTIMIZATION RESULTS\n');
fprintf('Length = %.4f m\n',L);
fprintf('Width  = %.4f m\n',W);
fprintf('Height = %.4f m\n',H);
fprintf('Minimum Cost = %.4f currency units\n',fval);

% Plot the cost function
[Lg,Wg] = meshgrid(0.8:0.02:2.5,...
                   0.8:0.02:2.5);

Hg = 3./(Lg.*Wg);

Cost = 40.*Lg.*Wg + ...
       50.*Lg.*Hg + ...
       50.*Wg.*Hg;

figure;
contourf(Lg,Wg,Cost,30);
colorbar;
hold on;
plot(L,W,'r*','MarkerSize',12);
xlabel('Length (m)');
ylabel('Width (m)');
title('GA: Material Cost Contour Plot');
legend('Cost','Optimal Dimensions');
grid on;

% 3D surface plot
figure;
surf(Lg,Wg,Cost);
shading interp;
colorbar;
hold on;
plot3(L,W,fval,'r*','MarkerSize',12);
xlabel('Length (m)');
ylabel('Width (m)');
zlabel('Material Cost');
title('GA: 3D Cost Surface');
grid on;