clc;
clear;
close all;

% LIVESTOCK FEED OPTIMIZATION USING FMINCON

% Decision variables:
% x(1) = Maize (kg)
% x(2) = Soybean meal (kg)
% x(3) = Wheat bran (kg)

% Objective function: Minimize total cost
f = [0.45; 0.85; 0.35];

% Inequality constraints: A*x <= b
A = [-0.09, -0.44, -0.16;    % Protein >= 18 kg
     -3300, -2450, -1800;    % Energy >= 280000 kcal
      0.02,  0.07,   0.10];  % Fibre <= 8 kg

b = [-18; -280000; 8];

% Equality constraint: total mass = 100 kg
Aeq = [1 1 1];
beq = 100;

% Lower and upper bounds
lb = [0; 0; 0];
ub = [100; 100; 100];

% Initial guess (feasible starting point)
x0 = [57; 22; 21];

% Optimization options
options = optimoptions('fmincon', ...
    'Algorithm', 'sqp', ...
    'Display', 'iter');

% Solve the optimization problem
[x, fval, exitflag, output] = fmincon( ...
    @(x) f' * x, x0, A, b, Aeq, beq, ...
    lb, ub, [], options);

% Display results
fprintf('\nOPTIMAL FEED MIX USING FMINCON\n');
fprintf('Maize       = %.4f kg\n', x(1));
fprintf('Soybean meal= %.4f kg\n', x(2));
fprintf('Wheat bran  = %.4f kg\n', x(3));
fprintf('Minimum cost= %.4f currency units\n', fval);

% Calculate actual nutritional contents
protein = 0.09*x(1) + 0.44*x(2) + 0.16*x(3);
energy  = 3300*x(1) + 2450*x(2) + 1800*x(3);
fibre   = 0.02*x(1) + 0.07*x(2) + 0.10*x(3);

fprintf('\nNUTRITIONAL RESULTS\n');
fprintf('Total mass = %.4f kg\n', sum(x));
fprintf('Protein    = %.4f kg (minimum 18 kg)\n', protein);
fprintf('Energy     = %.4f kcal (minimum 280000 kcal)\n', energy);
fprintf('Fibre      = %.4f kg (maximum 8 kg)\n', fibre);

% PLOT 1: Quantity of each ingredient
figure('Name','Fmincon - Ingredient Quantities');

bar(x);
set(gca, 'XTick', 1:3, ...
    'XTickLabel', {'Maize','Soybean meal','Wheat bran'});

ylabel('Quantity (kg)');
title('Optimal Feed Ingredient Quantities - Fmincon');
grid on;

% PLOT 2: Nutritional requirements
figure('Name','Fmincon - Nutrition');

subplot(3,1,1);
bar([protein 18]);
set(gca,'XTickLabel',{'Actual','Minimum'});
ylabel('Protein (kg)');
title('Protein Requirement');
grid on;

subplot(3,1,2);
bar([energy 280000]);
set(gca,'XTickLabel',{'Actual','Minimum'});
ylabel('Energy (kcal)');
title('Energy Requirement');
grid on;

subplot(3,1,3);
bar([fibre 8]);
set(gca,'XTickLabel',{'Actual','Maximum'});
ylabel('Fibre (kg)');
title('Fibre Limit');
grid on;

